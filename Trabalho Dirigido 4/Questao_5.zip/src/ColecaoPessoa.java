public class ColecaoPessoa implements Colecao{

    private Pessoa[] dados = new Pessoa[100];
    int posicaoCorente = 0;

    @Override
    public boolean iserir(Pessoa p) {
        if(posicaoCorente == 0){
            dados[posicaoCorente] = p;
            posicaoCorente++;
            return true;
        } else if(dados != null && posicaoCorente > 0){
            dados[posicaoCorente] = p;
            posicaoCorente++;
            return true;
        }else if(posicaoCorente >=100) {
            return false;
        }
        return false;
    }


    @Override
    public boolean remover() {
        if(dados == null){
            return false;
        } else {
            dados[posicaoCorente] = null;
            return true;
        }
    }

    @Override
    public boolean remover_indice(int i) {
        if(dados == null){
            return false;
        } else {
            dados[i-1] = null;
            return true;
        }
    }

    @Override
    public void atualizar(int i, Pessoa p) {
        if(i >= 100){
            System.out.println("Indice inválido");
        } else {
            dados[i-1] = p;
        }
    }

    @Override
    public boolean pesquisar(Pessoa p) {
        if(dados != null){
            for(Pessoa pessoa:dados){
                if(pessoa.equals(p)){
                    return true;
                }
            }
            return false;
        } else {
            return false;
        }
    }

    @Override
    public boolean colecaoEstaVazia() {
        return dados == null && posicaoCorente == 0;
    }

    @Override
    public void imprimirDadosColecao() {
        int i = 0;
        if(dados != null){
            for (Pessoa pessoa:dados){
                System.out.println("Pessoa " + i +"]: " + pessoa);
                i++;
            }
        } else {
            System.out.println("Coleção vazia!");
        }
    }

    @Override
    public Pessoa retornarObjeto(int i) {
        if (dados != null) {
            for (int x = 0; x < posicaoCorente; x++) {
                if (x == i - 1) {
                    return dados[x];
                }
            }
        } else {
            System.out.println("Coleção vazia!");
        }
        return null;
    }
}
