public class Main {
    public static void main(String[] args) {
        PessoaFisica pessoa = new PessoaFisica();

        pessoa.setNome("Carlos");
        pessoa.setCpf("aaaaaaaaaaaaaaa");

    }
}