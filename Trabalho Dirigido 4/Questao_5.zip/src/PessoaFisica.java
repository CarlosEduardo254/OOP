import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Objects;

public class PessoaFisica extends Pessoa{

    private String cpf;
    private Date dataNascimento;

    public String getCpf() {
        return cpf;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }


    @Override
    public boolean validarDocumento() {
        return this.cpf != null && this.cpf.length() == 14;
    }

    @Override
    public int calcularIdade() {
        Date hoje = new Date();
        GregorianCalendar atual = new GregorianCalendar();
        atual.setTime(hoje);

        int anoAtual = atual.get(GregorianCalendar.YEAR);

        GregorianCalendar nascimento = new GregorianCalendar();
        nascimento.setTime(getDataNascimento());


        int anoNascimento = nascimento.get(GregorianCalendar.YEAR);

        return anoAtual - anoNascimento;
    }

    @Override
    public String toString() {
        return "PessoaFisica[" + "nome: " + getNome() + "' | " +
                "cpf: '" + cpf + "' | " +
                "dataNascimento: " + dataNascimento +
                ']';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PessoaFisica that = (PessoaFisica) o;
        return Objects.equals(cpf, that.cpf);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cpf);
    }
}
