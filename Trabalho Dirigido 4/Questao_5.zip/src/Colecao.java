public interface Colecao {
    public boolean iserir(Pessoa p);
    public boolean remover();
    public boolean remover_indice(int i);
    public void atualizar(int i, Pessoa p);
    public boolean pesquisar(Pessoa p);
    public boolean colecaoEstaVazia();
    public void imprimirDadosColecao();
    public Pessoa retornarObjeto(int i);
}
