import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Objects;

public class PessoaJuridica extends Pessoa{

    private String cnpj;
    private Date dataCriacao;

    public String getCnpj() {
        return cnpj;
    }

    public Date getDataCriacao() {
        return dataCriacao;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }

    public void setDataCriacao(Date dataCriacao) {
        this.dataCriacao = dataCriacao;
    }

    public boolean validarDocumento(){
        return this.cnpj != null && this.cnpj.length() == 18;
    }

    public int calcularIdade(){
        Date hoje = new Date();
        GregorianCalendar atual = new GregorianCalendar();
        atual.setTime(hoje);

        int anoAtual = atual.get(GregorianCalendar.YEAR);

        GregorianCalendar criacao = new GregorianCalendar();
        criacao.setTime(getDataCriacao());


        int anoCriacao = criacao.get(GregorianCalendar.YEAR);

        return anoAtual - anoCriacao;
    }

    @Override
    public String toString() {
        return "PessoaJuridica[" +
                "nome: " + getNome() + " | " +
                "cnpj: '" + cnpj + "' | "+
                "dataCriacao=" + dataCriacao +
                ']';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PessoaJuridica that = (PessoaJuridica) o;
        return Objects.equals(cnpj, that.cnpj);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cnpj);
    }


}
